#!/bin/bash

# اجرا کردن اسکریپت پایتون
python send_message.py
